def classFactory(iface):
    from .plugin import TelecomTowersViewerPlugin
    return TelecomTowersViewerPlugin(iface)
