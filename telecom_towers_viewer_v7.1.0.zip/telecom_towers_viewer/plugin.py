from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

from .dock_widget import TelecomTowersDialog


PLUGIN_TITLE = "أداة تحليل الملاءمة المكانية لأبراج الاتصالات"


class TelecomTowersViewerPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.dialog = None

    def initGui(self):
        self.action = QAction(
            QIcon(self._icon_path()),
            PLUGIN_TITLE,
            self.iface.mainWindow(),
        )
        self.action.triggered.connect(self.show_window)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu(PLUGIN_TITLE, self.action)

    def unload(self):
        if self.dialog is not None:
            self.dialog.close()
            self.dialog.deleteLater()
            self.dialog = None
        if self.action is not None:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginMenu(PLUGIN_TITLE, self.action)
            self.action.deleteLater()
            self.action = None

    def show_window(self):
        if self.dialog is None:
            self.dialog = TelecomTowersDialog(self.iface)
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()

    @staticmethod
    def _icon_path():
        import os
        return os.path.join(os.path.dirname(__file__), "icon.svg")
