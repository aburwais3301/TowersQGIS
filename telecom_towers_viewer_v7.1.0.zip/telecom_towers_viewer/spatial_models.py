"""Safe NumPy/GDAL spatial models used by the Telecom Towers Viewer."""

import math
import os
import tempfile

import numpy as np
from osgeo import gdal, ogr, osr


EPSG = 32633
NODATA = -9999.0


def _grid(extent, cell):
    xmin, ymin, xmax, ymax = extent
    width = max(1, int(math.ceil((xmax - xmin) / cell)))
    height = max(1, int(math.ceil((ymax - ymin) / cell)))
    if width * height > 12_000_000:
        raise ValueError("حجم الخلية صغير جدًا وينتج راسترًا ضخمًا")
    gt = (xmin, cell, 0.0, ymax, 0.0, -cell)
    return width, height, gt


def _memory_raster(width, height, gt, dtype=gdal.GDT_Float32):
    ds = gdal.GetDriverByName("MEM").Create("", width, height, 1, dtype)
    ds.SetGeoTransform(gt)
    srs = osr.SpatialReference()
    srs.ImportFromEPSG(EPSG)
    ds.SetProjection(srs.ExportToWkt())
    return ds


def _rasterize(wkts, values, width, height, gt, default=0.0):
    ds = _memory_raster(width, height, gt)
    band = ds.GetRasterBand(1)
    band.Fill(default)
    vector = ogr.GetDriverByName("Memory").CreateDataSource("")
    srs = osr.SpatialReference(); srs.ImportFromEPSG(EPSG)
    layer = vector.CreateLayer("features", srs=srs, geom_type=ogr.wkbUnknown)
    layer.CreateField(ogr.FieldDefn("burn", ogr.OFTReal))
    definition = layer.GetLayerDefn()
    for wkt, value in zip(wkts, values):
        geometry = ogr.CreateGeometryFromWkt(wkt)
        if geometry is None:
            continue
        feature = ogr.Feature(definition)
        feature.SetGeometry(geometry)
        feature.SetField("burn", float(value))
        layer.CreateFeature(feature)
    gdal.RasterizeLayer(ds, [1], layer, options=["ATTRIBUTE=burn"])
    return ds.ReadAsArray().astype(np.float64)


def _mask(boundary_wkt, width, height, gt):
    return _rasterize([boundary_wkt], [1], width, height, gt, 0) > 0


def _proximity(wkts, width, height, gt):
    source = _memory_raster(width, height, gt, gdal.GDT_Byte)
    source.GetRasterBand(1).Fill(0)
    binary = _rasterize(wkts, [1] * len(wkts), width, height, gt, 0)
    source.GetRasterBand(1).WriteArray((binary > 0).astype(np.uint8))
    destination = _memory_raster(width, height, gt)
    gdal.ComputeProximity(source.GetRasterBand(1), destination.GetRasterBand(1), ["VALUES=1", "DISTUNITS=GEO"])
    return destination.ReadAsArray().astype(np.float64)


def _kde(points, width, height, gt, bandwidth):
    counts = np.zeros((height, width), dtype=np.float64)
    if not points:
        return counts
    cell = gt[1]
    for x, y in points:
        col = int((x - gt[0]) / cell)
        row = int((gt[3] - y) / cell)
        if 0 <= row < height and 0 <= col < width:
            counts[row, col] += 1.0
    sigma = max(0.5, bandwidth / cell)
    radius = max(1, int(math.ceil(3.0 * sigma)))
    axis = np.arange(-radius, radius + 1, dtype=np.float64)
    kernel = np.exp(-0.5 * (axis / sigma) ** 2)
    kernel /= kernel.sum()
    horizontal = np.apply_along_axis(lambda row: np.convolve(row, kernel, mode="same"), 1, counts)
    smoothed = np.apply_along_axis(lambda col: np.convolve(col, kernel, mode="same"), 0, horizontal)
    return smoothed * (1_000_000.0 / (cell * cell))


def _idw(points, width, height, gt, neighbours=12):
    values_out = np.full((height, width), np.nan, dtype=np.float64)
    support = np.full((height, width), np.inf, dtype=np.float64)
    if not points:
        return values_out, support
    data = np.asarray(points, dtype=np.float64)
    xs, ys, vals = data[:, 0], data[:, 1], data[:, 2]
    k = min(neighbours, len(points))
    grid_x = gt[0] + (np.arange(width) + 0.5) * gt[1]
    for row in range(height):
        grid_y = gt[3] + (row + 0.5) * gt[5]
        d2 = (grid_x[:, None] - xs[None, :]) ** 2 + (grid_y - ys[None, :]) ** 2
        nearest = np.argpartition(d2, k - 1, axis=1)[:, :k]
        selected = np.take_along_axis(d2, nearest, axis=1)
        selected_values = vals[nearest]
        weights = 1.0 / np.maximum(selected, 0.01)
        values_out[row] = (weights * selected_values).sum(axis=1) / weights.sum(axis=1)
        support[row] = np.sqrt(d2.min(axis=1))
    return values_out, support


def _normalize(array, mask):
    valid = array[mask & np.isfinite(array)]
    if valid.size == 0:
        return np.zeros_like(array)
    low, high = np.percentile(valid, [2, 98])
    if high <= low:
        return np.zeros_like(array)
    return np.clip((array - low) / (high - low), 0, 1)


def _write(array, gt, prefix, description):
    handle, path = tempfile.mkstemp(prefix=prefix, suffix=".tif")
    os.close(handle)
    height, width = array.shape
    ds = gdal.GetDriverByName("GTiff").Create(path, width, height, 1, gdal.GDT_Float32,
                                               options=["COMPRESS=LZW", "TILED=YES"])
    ds.SetGeoTransform(gt)
    srs = osr.SpatialReference(); srs.ImportFromEPSG(EPSG)
    ds.SetProjection(srs.ExportToWkt())
    band = ds.GetRasterBand(1)
    band.SetNoDataValue(NODATA)
    band.SetDescription(description)
    band.WriteArray(array.astype(np.float32))
    band.FlushCache(); ds.FlushCache(); ds = None
    return path


def create_kde(boundary_wkt, extent, tower_points, cell_size, bandwidth):
    width, height, gt = _grid(extent, cell_size)
    mask = _mask(boundary_wkt, width, height, gt)
    density = _kde(tower_points, width, height, gt, bandwidth)
    density[~mask] = NODATA
    return _write(density, gt, "telecom_kde_", "Towers per km2")


def create_suitability(boundary_wkt, extent, towers, buildings, roads, landuses,
                       measurements, cell_size, weights, measurement_support=1500.0):
    width, height, gt = _grid(extent, cell_size)
    mask = _mask(boundary_wkt, width, height, gt)
    building_density = _kde(buildings, width, height, gt, 500.0)
    building_score = _normalize(building_density, mask)
    tower_wkts = [f"POINT ({x} {y})" for x, y in towers]
    tower_distance = _proximity(tower_wkts, width, height, gt)
    tower_score = np.clip(tower_distance / 2000.0, 0, 1)
    road_distance = _proximity(roads, width, height, gt)
    road_score = 1.0 - np.clip(road_distance / 1000.0, 0, 1)
    land_wkts = [item[0] for item in landuses]
    land_values = [item[1] for item in landuses]
    land_score = _rasterize(land_wkts, land_values, width, height, gt, 0.3)
    rsrp, support = _idw(measurements, width, height, gt)
    rsrp_score = 1.0 - _normalize(rsrp, mask & (support <= measurement_support))
    rsrp_available = np.isfinite(rsrp) & (support <= measurement_support)

    layers = [building_score, rsrp_score, tower_score, road_score, land_score]
    available = [np.ones_like(mask, dtype=bool), rsrp_available,
                 np.ones_like(mask, dtype=bool), np.ones_like(mask, dtype=bool),
                 np.ones_like(mask, dtype=bool)]
    numerator = np.zeros((height, width), dtype=np.float64)
    denominator = np.zeros((height, width), dtype=np.float64)
    for layer, valid, weight in zip(layers, available, weights):
        numerator += np.where(valid, layer * weight, 0.0)
        denominator += np.where(valid, weight, 0.0)
    score = np.divide(numerator, denominator, out=np.zeros_like(numerator), where=denominator > 0) * 100.0
    score[~mask] = NODATA
    path = _write(score, gt, "telecom_suitability_", "Suitability 0-100")

    candidates = []
    working = score.copy()
    separation_pixels = max(1, int(round(500.0 / cell_size)))
    for rank in range(1, 11):
        flat = int(np.argmax(working))
        row, col = np.unravel_index(flat, working.shape)
        value = working[row, col]
        if value < 0:
            break
        x = gt[0] + (col + 0.5) * gt[1]
        y = gt[3] + (row + 0.5) * gt[5]
        candidates.append((rank, float(value), float(x), float(y)))
        r0=max(0,row-separation_pixels); r1=min(height,row+separation_pixels+1)
        c0=max(0,col-separation_pixels); c1=min(width,col+separation_pixels+1)
        yy, xx = np.ogrid[r0:r1, c0:c1]
        disk = (yy-row)**2 + (xx-col)**2 <= separation_pixels**2
        block = working[r0:r1, c0:c1]; block[disk] = NODATA
    return path, candidates
