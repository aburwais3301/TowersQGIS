import os

from qgis.PyQt.QtCore import Qt, QVariant
from qgis.PyQt.QtGui import QColor, QPixmap
from qgis.PyQt.QtWidgets import (
    QComboBox,
    QApplication,
    QDoubleSpinBox,
    QDialog,
    QFrame,
    QFileDialog,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QProgressBar,
    QScrollArea,
    QSpinBox,
    QHeaderView,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)
from qgis.core import (
    Qgis,
    QgsCategorizedSymbolRenderer,
    QgsColorRampShader,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsGraduatedSymbolRenderer,
    QgsGeometry,
    QgsFeature,
    QgsFeatureRequest,
    QgsField,
    QgsFillSymbol,
    QgsMarkerSymbol,
    QgsPointXY,
    QgsProject,
    QgsProviderRegistry,
    QgsRendererCategory,
    QgsRendererRange,
    QgsRasterLayer,
    QgsRasterShader,
    QgsSingleBandPseudoColorRenderer,
    QgsSpatialIndex,
    QgsVectorLayer,
    QgsVectorLayerExporter,
    QgsDataSourceUri,
)

from .spatial_models import create_kde, create_suitability


LAYER_NAME = "أبراج الاتصالات"
SCHEMA_NAME = "telecom"
VIEW_NAME = "qgis_towers"
GEOMETRY_COLUMN = "geom"
PRIMARY_KEY = "tower_id"
DEFAULT_CONNECTION = "Telecom Towers"
MEASUREMENTS_LAYER_NAME = "نقاط قياس الشبكة"
MEASUREMENTS_VIEW_NAME = "qgis_measurements"
STUDY_AREA_LAYER_NAME = "حدود منطقة الدراسة - نطاق الأبراج"
OSM_OUTPUTS = {
    "roads": ("طرق منطقة الدراسة", "study_roads", "MultiLineString"),
    "buildings": ("مباني منطقة الدراسة", "study_buildings", "MultiPolygon"),
    "landuse": ("استعمالات أراضي منطقة الدراسة", "study_landuse", "MultiPolygon"),
    "places": ("مدن وأحياء منطقة الدراسة", "study_places", "Point"),
}

DEFAULT_CLASSES = {
    "rsrp_dbm": [
        ["ضعيفة جدًا", -140, -110, "#B71C1C"], ["ضعيفة", -110, -100, "#F57C00"],
        ["متوسطة", -100, -90, "#FDD835"], ["جيدة", -90, -80, "#7CB342"], ["ممتازة", -80, -40, "#1B5E20"],
    ],
    "rsrq_db": [
        ["ضعيفة جدًا", -35, -20, "#B71C1C"], ["ضعيفة", -20, -15, "#F57C00"],
        ["متوسطة", -15, -10, "#FDD835"], ["جيدة", -10, -6, "#7CB342"], ["ممتازة", -6, 0, "#1B5E20"],
    ],
    "snr_db": [
        ["ضعيفة جدًا", -30, 0, "#B71C1C"], ["ضعيفة", 0, 5, "#F57C00"],
        ["متوسطة", 5, 10, "#FDD835"], ["جيدة", 10, 20, "#7CB342"], ["ممتازة", 20, 40, "#1B5E20"],
    ],
}

try:
    ALIGN_CENTER = Qt.AlignmentFlag.AlignCenter
    SCROLL_AS_NEEDED = Qt.ScrollBarPolicy.ScrollBarAsNeeded
    WINDOW_MINIMIZE = Qt.WindowType.WindowMinimizeButtonHint
    WINDOW_MAXIMIZE = Qt.WindowType.WindowMaximizeButtonHint
    ITEM_EDITABLE = Qt.ItemFlag.ItemIsEditable
    KEEP_ASPECT = Qt.AspectRatioMode.KeepAspectRatio
    SMOOTH_TRANSFORM = Qt.TransformationMode.SmoothTransformation
except AttributeError:
    ALIGN_CENTER = Qt.AlignCenter
    SCROLL_AS_NEEDED = Qt.ScrollBarAsNeeded
    WINDOW_MINIMIZE = Qt.WindowMinimizeButtonHint
    WINDOW_MAXIMIZE = Qt.WindowMaximizeButtonHint
    ITEM_EDITABLE = Qt.ItemIsEditable
    KEEP_ASPECT = Qt.KeepAspectRatio
    SMOOTH_TRANSFORM = Qt.SmoothTransformation

try:
    FRAME_HLINE = QFrame.Shape.HLine
    FRAME_SUNKEN = QFrame.Shadow.Sunken
    FRAME_NO_FRAME = QFrame.Shape.NoFrame
except AttributeError:
    FRAME_HLINE = QFrame.HLine
    FRAME_SUNKEN = QFrame.Sunken
    FRAME_NO_FRAME = QFrame.NoFrame


def message_level(name):
    enum = getattr(Qgis, "MessageLevel", None)
    return getattr(enum, name) if enum is not None else getattr(Qgis, name)


class TelecomTowersDialog(QDialog):
    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self.layer = None
        self.measurements_layer = None
        self.class_settings = {key: [row[:] for row in rows] for key, rows in DEFAULT_CLASSES.items()}
        self.active_heatmap_metric = "rsrp_dbm"
        self.setObjectName("TelecomTowersViewerDialog")
        self.setWindowTitle("أداة تحليل الملاءمة المكانية لأبراج الاتصالات")
        self.setWindowFlags(self.windowFlags() | WINDOW_MINIMIZE | WINDOW_MAXIMIZE)
        self.setMinimumSize(420, 420)
        self.resize(760, 780)
        self.setModal(False)
        self._build_ui()
        self.refresh_connections()
        self._update_counts()

    def _build_ui(self):
        outer_layout = QVBoxLayout(self)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        scroll_area = QScrollArea(self)
        scroll_area.setWidgetResizable(True)
        scroll_area.setFrameShape(FRAME_NO_FRAME)
        scroll_area.setHorizontalScrollBarPolicy(SCROLL_AS_NEEDED)
        scroll_area.setVerticalScrollBarPolicy(SCROLL_AS_NEEDED)
        content_widget = QWidget()
        content_widget.setMinimumWidth(620)
        layout = QVBoxLayout(content_widget)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        academic_header = QFrame()
        academic_header.setStyleSheet(
            "QFrame {background:#F7F9FC;border:1px solid #D7E0EA;border-radius:7px;}"
            "QLabel {border:none;background:transparent;}"
        )
        academic_layout = QHBoxLayout(academic_header)
        academic_layout.setContentsMargins(12, 10, 12, 10)
        logo_label = QLabel()
        logo_label.setFixedSize(105, 105)
        logo_label.setAlignment(ALIGN_CENTER)
        logo_path = os.path.join(os.path.dirname(__file__), "university_logo.png")
        logo = QPixmap(logo_path)
        if not logo.isNull():
            logo_label.setPixmap(logo.scaled(100, 100, KEEP_ASPECT, SMOOTH_TRANSFORM))
        academic_layout.addWidget(logo_label)

        academic_text_layout = QVBoxLayout()
        university_label = QLabel("جامعة المرقب\nكلية الهندسة - الخمس\nقسم الهندسة المدنية")
        university_label.setAlignment(ALIGN_CENTER)
        university_label.setStyleSheet("font-size:13px;font-weight:700;color:#17365D;")
        academic_text_layout.addWidget(university_label)
        title = QLabel("أداة تحليل الملاءمة المكانية لأبراج الاتصالات")
        title.setAlignment(ALIGN_CENTER)
        title.setWordWrap(True)
        title.setStyleSheet("font-size:18px;font-weight:800;color:#0F4C5C;margin-top:3px;")
        academic_text_layout.addWidget(title)
        research_label = QLabel("استخدام تطبيقات نظم المعلومات المكانية لزيادة كفاءة أبراج شبكات الاتصالات")
        research_label.setAlignment(ALIGN_CENTER)
        research_label.setWordWrap(True)
        research_label.setStyleSheet("font-size:12px;font-weight:700;color:#2E5E75;")
        academic_text_layout.addWidget(research_label)
        people_label = QLabel(
            "اسم الطالب: خالد محمد العربي الشلتات\n"
            "إشراف: د. صلاح معمر أبوراوي - أستاذ مساعد"
        )
        people_label.setAlignment(ALIGN_CENTER)
        people_label.setWordWrap(True)
        people_label.setStyleSheet("font-size:11px;color:#374151;")
        academic_text_layout.addWidget(people_label)
        academic_layout.addLayout(academic_text_layout, 1)
        layout.addWidget(academic_header)

        connection_group = QGroupBox("اتصال قاعدة البيانات")
        connection_layout = QVBoxLayout(connection_group)
        self.connection_combo = QComboBox()
        connection_layout.addWidget(self.connection_combo)

        connection_buttons = QHBoxLayout()
        refresh_button = QPushButton("تحديث الاتصالات")
        refresh_button.clicked.connect(self.refresh_connections)
        load_button = QPushButton("تحميل الأبراج")
        load_button.setStyleSheet(
            "QPushButton {background:#17365D;color:white;padding:7px;font-weight:600;}"
            "QPushButton:hover {background:#244F82;}"
        )
        load_button.clicked.connect(self.load_layer)
        connection_buttons.addWidget(refresh_button)
        connection_buttons.addWidget(load_button)
        connection_layout.addLayout(connection_buttons)
        layout.addWidget(connection_group)

        display_group = QGroupBox("التحكم في العرض")
        display_layout = QVBoxLayout(display_group)
        self.all_button = QPushButton("عرض جميع الأبراج")
        self.almadar_button = QPushButton("عرض المدار الجديد فقط")
        self.libyana_button = QPushButton("عرض ليبيانا فقط")
        self.all_button.clicked.connect(lambda: self.apply_filter("ALL"))
        self.almadar_button.clicked.connect(lambda: self.apply_filter("ALMADAR"))
        self.libyana_button.clicked.connect(lambda: self.apply_filter("LIBYANA"))
        display_layout.addWidget(self.all_button)
        display_layout.addWidget(self.almadar_button)
        display_layout.addWidget(self.libyana_button)
        layout.addWidget(display_group)

        measurements_group = QGroupBox("نقاط قياس الشبكة")
        measurements_layout = QVBoxLayout(measurements_group)
        load_measurements_button = QPushButton("تحميل نقاط القياس")
        load_measurements_button.setStyleSheet(
            "QPushButton {background:#276749;color:white;padding:7px;font-weight:600;}"
            "QPushButton:hover {background:#2F855A;}"
        )
        load_measurements_button.clicked.connect(self.load_measurements)
        measurements_layout.addWidget(load_measurements_button)

        metric_row = QHBoxLayout()
        metric_row.addWidget(QLabel("المؤشر المعروض:"))
        self.metric_combo = QComboBox()
        self.metric_combo.addItem("قوة الإشارة RSRP", "rsrp_dbm")
        self.metric_combo.addItem("جودة الإشارة RSRQ", "rsrq_db")
        self.metric_combo.addItem("نسبة الإشارة إلى الضوضاء SNR", "snr_db")
        self.metric_combo.currentIndexChanged.connect(self.apply_measurement_style)
        metric_row.addWidget(self.metric_combo, 1)
        measurements_layout.addLayout(metric_row)

        measurement_filter_row = QHBoxLayout()
        for label, code in [("الكل", "ALL"), ("المدار", "ALMADAR"), ("ليبيانا", "LIBYANA")]:
            button = QPushButton(label)
            button.clicked.connect(lambda checked=False, value=code: self.filter_measurements(value))
            measurement_filter_row.addWidget(button)
        measurements_layout.addLayout(measurement_filter_row)

        self.measurements_status_label = QLabel("لم يتم تحميل نقاط القياس بعد")
        self.measurements_status_label.setAlignment(ALIGN_CENTER)
        self.measurements_status_label.setWordWrap(True)
        self.measurements_status_label.setStyleSheet("background:#F0FFF4;padding:8px;border-radius:4px;")
        measurements_layout.addWidget(self.measurements_status_label)

        zoom_measurements_button = QPushButton("تقريب إلى نقاط القياس")
        zoom_measurements_button.clicked.connect(self.zoom_to_measurements)
        measurements_layout.addWidget(zoom_measurements_button)
        layout.addWidget(measurements_group)

        heatmap_group = QGroupBox("خرائط جودة الشبكة - IDW")
        heatmap_layout = QVBoxLayout(heatmap_group)
        heatmap_options = QHBoxLayout()
        heatmap_options.addWidget(QLabel("الشركة:"))
        self.heatmap_operator_combo = QComboBox()
        self.heatmap_operator_combo.addItem("المدار الجديد", "ALMADAR")
        self.heatmap_operator_combo.addItem("ليبيانا", "LIBYANA")
        heatmap_options.addWidget(self.heatmap_operator_combo)
        heatmap_options.addWidget(QLabel("المؤشر:"))
        self.heatmap_metric_combo = QComboBox()
        self.heatmap_metric_combo.addItem("RSRP", "rsrp_dbm")
        self.heatmap_metric_combo.addItem("RSRQ", "rsrq_db")
        self.heatmap_metric_combo.addItem("SNR", "snr_db")
        self.heatmap_metric_combo.currentIndexChanged.connect(self._heatmap_metric_changed)
        heatmap_options.addWidget(self.heatmap_metric_combo)
        heatmap_options.addWidget(QLabel("حجم الخلية (م):"))
        self.pixel_size_spin = QDoubleSpinBox()
        self.pixel_size_spin.setRange(5, 500)
        self.pixel_size_spin.setValue(20)
        self.pixel_size_spin.setDecimals(0)
        heatmap_options.addWidget(self.pixel_size_spin)
        heatmap_options.addWidget(QLabel("الجيران:"))
        self.neighbors_spin = QSpinBox()
        self.neighbors_spin.setRange(3, 100)
        self.neighbors_spin.setValue(12)
        heatmap_options.addWidget(self.neighbors_spin)
        heatmap_layout.addLayout(heatmap_options)

        self.classes_table = QTableWidget(5, 4)
        self.classes_table.setHorizontalHeaderLabels(["الفئة", "من", "إلى", "اللون HEX"])
        self.classes_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.classes_table.setMaximumHeight(190)
        heatmap_layout.addWidget(self.classes_table)
        class_buttons = QHBoxLayout()
        reset_classes_button = QPushButton("إعادة التصنيفات الافتراضية")
        reset_classes_button.clicked.connect(self.reset_heatmap_classes)
        create_heatmap_button = QPushButton("إنشاء خريطة IDW")
        create_heatmap_button.setStyleSheet("QPushButton {background:#6B46C1;color:white;padding:8px;font-weight:700;}")
        create_heatmap_button.clicked.connect(self.create_idw_heatmap)
        class_buttons.addWidget(reset_classes_button)
        class_buttons.addWidget(create_heatmap_button)
        heatmap_layout.addLayout(class_buttons)
        layout.addWidget(heatmap_group)
        self._load_classes_table("rsrp_dbm")

        nearest_group = QGroupBox("تحليل الجار الأقرب للأبراج")
        nearest_layout = QVBoxLayout(nearest_group)
        boundary_row = QHBoxLayout()
        boundary_row.addWidget(QLabel("حزام حدود الدراسة (م):"))
        self.study_buffer_spin = QDoubleSpinBox()
        self.study_buffer_spin.setRange(100, 10000)
        self.study_buffer_spin.setValue(1000)
        self.study_buffer_spin.setDecimals(0)
        self.study_buffer_spin.setSingleStep(100)
        boundary_row.addWidget(self.study_buffer_spin)
        create_boundary_button = QPushButton("إنشاء الحدود من جميع الأبراج")
        create_boundary_button.setStyleSheet(
            "QPushButton {background:#2B6CB0;color:white;padding:7px;font-weight:700;}"
        )
        create_boundary_button.clicked.connect(self.create_tower_study_area)
        boundary_row.addWidget(create_boundary_button, 1)
        nearest_layout.addLayout(boundary_row)
        nearest_options = QHBoxLayout()
        nearest_options.addWidget(QLabel("الأبراج:"))
        self.nearest_operator_combo = QComboBox()
        self.nearest_operator_combo.addItem("جميع الشركات", "ALL")
        self.nearest_operator_combo.addItem("المدار الجديد", "ALMADAR")
        self.nearest_operator_combo.addItem("ليبيانا", "LIBYANA")
        nearest_options.addWidget(self.nearest_operator_combo)
        nearest_options.addWidget(QLabel("منطقة الدراسة:"))
        self.study_area_combo = QComboBox()
        nearest_options.addWidget(self.study_area_combo, 1)
        refresh_areas_button = QPushButton("تحديث الحدود")
        refresh_areas_button.clicked.connect(self.refresh_study_areas)
        nearest_options.addWidget(refresh_areas_button)
        nearest_layout.addLayout(nearest_options)

        run_nearest_button = QPushButton("تنفيذ تحليل الجار الأقرب")
        run_nearest_button.setStyleSheet("QPushButton {background:#0B7285;color:white;padding:8px;font-weight:700;}")
        run_nearest_button.clicked.connect(self.run_nearest_neighbor)
        nearest_layout.addWidget(run_nearest_button)
        self.nearest_results_table = QTableWidget(0, 3)
        self.nearest_results_table.setHorizontalHeaderLabels(["المؤشر", "القيمة", "التفسير"])
        self.nearest_results_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.nearest_results_table.setMaximumHeight(230)
        nearest_layout.addWidget(self.nearest_results_table)
        self.nearest_note_label = QLabel("لنتيجة علمية دقيقة اختر طبقة مضلعة تمثل الحدود الفعلية لمنطقة الدراسة.")
        self.nearest_note_label.setWordWrap(True)
        self.nearest_note_label.setStyleSheet("color:#5B6573;")
        nearest_layout.addWidget(self.nearest_note_label)
        layout.addWidget(nearest_group)
        self.refresh_study_areas()

        osm_group = QGroupBox("استخراج بيانات OpenStreetMap داخل منطقة الدراسة")
        osm_layout = QVBoxLayout(osm_group)
        osm_file_row = QHBoxLayout()
        self.osm_path_edit = QLineEdit()
        self.osm_path_edit.setPlaceholderText("اختر ملف ليبيا بصيغة .osm.pbf")
        browse_osm_button = QPushButton("اختيار ملف OSM")
        browse_osm_button.clicked.connect(self.browse_osm_file)
        osm_file_row.addWidget(self.osm_path_edit, 1)
        osm_file_row.addWidget(browse_osm_button)
        osm_layout.addLayout(osm_file_row)
        extract_osm_button = QPushButton("استخراج وحفظ الطبقات في PostGIS")
        extract_osm_button.setStyleSheet(
            "QPushButton {background:#9C4A10;color:white;padding:8px;font-weight:700;}"
        )
        extract_osm_button.clicked.connect(self.extract_osm_data)
        osm_layout.addWidget(extract_osm_button)
        self.osm_progress = QProgressBar()
        self.osm_progress.setRange(0, 4)
        self.osm_progress.setValue(0)
        self.osm_progress.setFormat("جاهز للاستخراج")
        osm_layout.addWidget(self.osm_progress)
        self.osm_status_label = QLabel(
            "النواتج: الطرق، المباني، استعمالات الأراضي، والمدن والأحياء داخل الحدود المختارة."
        )
        self.osm_status_label.setWordWrap(True)
        osm_layout.addWidget(self.osm_status_label)
        layout.addWidget(osm_group)

        relations_group = QGroupBox("العلاقة المكانية بين الأبراج والعمران")
        relations_layout = QVBoxLayout(relations_group)
        relations_options = QHBoxLayout()
        relations_options.addWidget(QLabel("نصف قطر التحليل (م):"))
        self.relation_radius_spin = QDoubleSpinBox()
        self.relation_radius_spin.setRange(100, 5000)
        self.relation_radius_spin.setValue(500)
        self.relation_radius_spin.setDecimals(0)
        self.relation_radius_spin.setSingleStep(100)
        relations_options.addWidget(self.relation_radius_spin)
        run_relations_button = QPushButton("تحليل المباني والطرق واستعمالات الأراضي")
        run_relations_button.setStyleSheet(
            "QPushButton {background:#5F3DC4;color:white;padding:8px;font-weight:700;}"
        )
        run_relations_button.clicked.connect(self.run_spatial_relations)
        relations_options.addWidget(run_relations_button, 1)
        relations_layout.addLayout(relations_options)

        self.relations_tabs = QTabWidget()
        self.building_relation_table = QTableWidget(0, 8)
        self.building_relation_table.setHorizontalHeaderLabels([
            "البرج", "الشركة", "عدد المباني", "مساحة المباني م²",
            "مبنى/كم²", "تغطية المباني %", "تصنيف الكثافة", "نصف القطر م",
        ])
        self.road_relation_table = QTableWidget(0, 7)
        self.road_relation_table.setHorizontalHeaderLabels([
            "البرج", "الشركة", "أقرب طريق م", "نوع الطريق",
            "طول الطرق كم", "كثافة الطرق كم/كم²", "نصف القطر م",
        ])
        self.landuse_relation_table = QTableWidget(0, 3)
        self.landuse_relation_table.setHorizontalHeaderLabels([
            "استعمال الأرض", "عدد الأبراج", "النسبة المئوية (%)",
        ])
        for table in (
            self.building_relation_table, self.road_relation_table, self.landuse_relation_table
        ):
            table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            table.setMinimumHeight(250)
            table.setSortingEnabled(True)
        self.relations_tabs.addTab(self.building_relation_table, "كثافة المباني")
        self.relations_tabs.addTab(self.road_relation_table, "الطرق")
        self.relations_tabs.addTab(self.landuse_relation_table, "استعمالات الأراضي")
        relations_layout.addWidget(self.relations_tabs)
        self.relations_status_label = QLabel("يجب تحميل الأبراج وطبقات OSM الأربع قبل تنفيذ التحليل.")
        self.relations_status_label.setWordWrap(True)
        relations_layout.addWidget(self.relations_status_label)
        layout.addWidget(relations_group)

        models_group = QGroupBox("KDE ونموذج الملاءمة المكانية")
        models_layout = QVBoxLayout(models_group)
        kde_row = QHBoxLayout()
        kde_row.addWidget(QLabel("KDE للأبراج:"))
        self.kde_operator_combo = QComboBox()
        self.kde_operator_combo.addItem("جميع الشركات", "ALL")
        self.kde_operator_combo.addItem("المدار الجديد", "ALMADAR")
        self.kde_operator_combo.addItem("ليبيانا", "LIBYANA")
        kde_row.addWidget(self.kde_operator_combo)
        kde_row.addWidget(QLabel("نطاق البحث (م):"))
        self.kde_bandwidth_spin = QDoubleSpinBox(); self.kde_bandwidth_spin.setRange(100, 5000)
        self.kde_bandwidth_spin.setValue(750); self.kde_bandwidth_spin.setDecimals(0)
        kde_row.addWidget(self.kde_bandwidth_spin)
        kde_row.addWidget(QLabel("الخلية (م):"))
        self.model_cell_spin = QDoubleSpinBox(); self.model_cell_spin.setRange(20, 500)
        self.model_cell_spin.setValue(50); self.model_cell_spin.setDecimals(0)
        kde_row.addWidget(self.model_cell_spin)
        create_kde_button = QPushButton("إنشاء KDE")
        create_kde_button.clicked.connect(self.create_tower_kde)
        kde_row.addWidget(create_kde_button)
        models_layout.addLayout(kde_row)

        suitability_row = QHBoxLayout()
        suitability_row.addWidget(QLabel("نموذج الملاءمة للشركة:"))
        self.suitability_operator_combo = QComboBox()
        self.suitability_operator_combo.addItem("المدار الجديد", "ALMADAR")
        self.suitability_operator_combo.addItem("ليبيانا", "LIBYANA")
        suitability_row.addWidget(self.suitability_operator_combo)
        self.suitability_weight_spins = []
        for label, value in [("المباني", 30), ("ضعف RSRP", 25), ("بعد الأبراج", 20), ("قرب الطرق", 15), ("الأرض", 10)]:
            suitability_row.addWidget(QLabel(label))
            spin = QDoubleSpinBox(); spin.setRange(0, 100); spin.setValue(value); spin.setDecimals(0)
            spin.setSuffix("%")
            suitability_row.addWidget(spin)
            self.suitability_weight_spins.append(spin)
        models_layout.addLayout(suitability_row)

        models_layout.addWidget(QLabel("درجات ملاءمة استعمالات الأراضي (0–100):"))
        self.landuse_scores_table = QTableWidget(7, 2)
        self.landuse_scores_table.setHorizontalHeaderLabels(["استعمال الأرض", "درجة الملاءمة"])
        self.landuse_scores_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.landuse_scores_table.setMaximumHeight(205)
        land_scores = [
            ("المناطق السكنية", 80), ("المناطق التجارية", 100),
            ("المناطق الصناعية", 70), ("المناطق الإدارية والخدمية", 90),
            ("المناطق المفتوحة والخضراء", 60), ("النقل والمرافق", 50),
            ("غير مصنف/أخرى", 30),
        ]
        for row, (name, score) in enumerate(land_scores):
            name_item = QTableWidgetItem(name); name_item.setFlags(name_item.flags() & ~ITEM_EDITABLE)
            self.landuse_scores_table.setItem(row, 0, name_item)
            self.landuse_scores_table.setItem(row, 1, QTableWidgetItem(str(score)))
        models_layout.addWidget(self.landuse_scores_table)
        create_suitability_button = QPushButton("إنشاء نموذج الملاءمة واستخراج أفضل المواقع")
        create_suitability_button.setStyleSheet(
            "QPushButton {background:#0F766E;color:white;padding:8px;font-weight:700;}"
        )
        create_suitability_button.clicked.connect(self.create_suitability_model)
        models_layout.addWidget(create_suitability_button)
        self.candidates_table = QTableWidget(0, 4)
        self.candidates_table.setHorizontalHeaderLabels(["الترتيب", "درجة الملاءمة", "خط الطول", "خط العرض"])
        self.candidates_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.candidates_table.setMaximumHeight(230)
        models_layout.addWidget(self.candidates_table)
        self.models_status_label = QLabel("KDE يمثل كثافة الأبراج (برج/كم²)، والملاءمة تمثل أولوية المواقع الجديدة من 0 إلى 100.")
        self.models_status_label.setWordWrap(True)
        models_layout.addWidget(self.models_status_label)
        layout.addWidget(models_group)

        separator = QFrame()
        separator.setFrameShape(FRAME_HLINE)
        separator.setFrameShadow(FRAME_SUNKEN)
        layout.addWidget(separator)

        self.status_label = QLabel("لم يتم تحميل الطبقة بعد")
        self.status_label.setWordWrap(True)
        self.status_label.setAlignment(ALIGN_CENTER)
        self.status_label.setStyleSheet("background:#F3F6F9;padding:10px;border-radius:4px;")
        layout.addWidget(self.status_label)

        zoom_button = QPushButton("تقريب إلى الأبراج المعروضة")
        zoom_button.clicked.connect(self.zoom_to_visible)
        layout.addWidget(zoom_button)
        layout.addStretch(1)
        scroll_area.setWidget(content_widget)
        outer_layout.addWidget(scroll_area)

    def refresh_connections(self):
        selected = self.connection_combo.currentText()
        self.connection_combo.clear()
        try:
            metadata = QgsProviderRegistry.instance().providerMetadata("postgres")
            names = sorted(metadata.connections().keys())
        except Exception as exc:
            self._message("تعذر قراءة اتصالات PostgreSQL", str(exc), message_level("Critical"))
            names = []

        self.connection_combo.addItems(names)
        preferred = selected or DEFAULT_CONNECTION
        index = self.connection_combo.findText(preferred)
        if index >= 0:
            self.connection_combo.setCurrentIndex(index)
        elif names:
            self.connection_combo.setCurrentIndex(0)

        if not names:
            self.status_label.setText(
                "لا يوجد اتصال PostgreSQL محفوظ. أنشئ اتصالًا باسم Telecom Towers من لوحة Browser."
            )

    def load_layer(self):
        connection_name = self.connection_combo.currentText().strip()
        if not connection_name:
            self._message(
                "اتصال غير محدد",
                "أنشئ اتصال PostgreSQL داخل QGIS ثم اضغط تحديث الاتصالات.",
                message_level("Warning"),
            )
            return

        existing = QgsProject.instance().mapLayersByName(LAYER_NAME)
        if existing:
            self.layer = existing[0]
            self.apply_filter("ALL")
            return

        try:
            metadata = QgsProviderRegistry.instance().providerMetadata("postgres")
            connection = metadata.findConnection(connection_name)
            base_uri = connection.uri()
            separator = "" if base_uri.endswith(" ") else " "
            layer_uri = (
                f"{base_uri}{separator}key='{PRIMARY_KEY}' "
                f"srid=4326 type=Point table=\"{SCHEMA_NAME}\".\"{VIEW_NAME}\" "
                f"({GEOMETRY_COLUMN}) sql="
            )
            layer = QgsVectorLayer(layer_uri, LAYER_NAME, "postgres")
        except Exception as exc:
            self._message("فشل إنشاء الاتصال", str(exc), message_level("Critical"))
            return

        if not layer.isValid():
            self._message(
                "تعذر تحميل الأبراج",
                "تحقق من الاتصال ومن وجود telecom.qgis_towers، ثم أعد المحاولة.",
                message_level("Critical"),
            )
            return

        self.layer = layer
        self._apply_style()
        QgsProject.instance().addMapLayer(layer)
        self.apply_filter("ALL")
        self.zoom_to_visible()
        self._message("تم التحميل", "تم تحميل طبقة أبراج الاتصالات بنجاح.", message_level("Success"))

    def _apply_style(self):
        if self.layer is None:
            return
        categories = []
        for value, label, color in [
            ("ALMADAR", "المدار الجديد", "#E31E24"),
            ("LIBYANA", "ليبيانا", "#1E88E5"),
        ]:
            symbol = QgsMarkerSymbol.createSimple({
                "name": "circle",
                "color": color,
                "outline_color": "#FFFFFF",
                "outline_width": "0.6",
                "size": "4.0",
            })
            categories.append(QgsRendererCategory(value, symbol, label))
        self.layer.setRenderer(QgsCategorizedSymbolRenderer("operator_code", categories))
        self.layer.triggerRepaint()

    def load_measurements(self):
        connection_name = self.connection_combo.currentText().strip()
        if not connection_name:
            self._message("اتصال غير محدد", "اختر اتصال PostgreSQL أولًا.", message_level("Warning"))
            return
        existing = QgsProject.instance().mapLayersByName(MEASUREMENTS_LAYER_NAME)
        if existing:
            self.measurements_layer = existing[0]
            self.filter_measurements("ALL")
            return
        try:
            metadata = QgsProviderRegistry.instance().providerMetadata("postgres")
            connection = metadata.findConnection(connection_name)
            base_uri = connection.uri()
            separator = "" if base_uri.endswith(" ") else " "
            layer_uri = (
                f"{base_uri}{separator}key='measurement_id' srid=4326 type=Point "
                f"table=\"{SCHEMA_NAME}\".\"{MEASUREMENTS_VIEW_NAME}\" ({GEOMETRY_COLUMN}) sql="
            )
            layer = QgsVectorLayer(layer_uri, MEASUREMENTS_LAYER_NAME, "postgres")
        except Exception as exc:
            self._message("فشل إنشاء طبقة القياسات", str(exc), message_level("Critical"))
            return
        if not layer.isValid():
            self._message("تعذر تحميل القياسات", "نفّذ سكربت المرحلة الثانية وتحقق من telecom.qgis_measurements.", message_level("Critical"))
            return
        self.measurements_layer = layer
        QgsProject.instance().addMapLayer(layer)
        self.apply_measurement_style()
        self.filter_measurements("ALL")
        self.zoom_to_measurements()
        self._message("تم التحميل", "تم تحميل نقاط قياس الشبكة.", message_level("Success"))

    def apply_measurement_style(self):
        if self.measurements_layer is None or not self.measurements_layer.isValid():
            return
        field = self.metric_combo.currentData()
        schemes = {
            "rsrp_dbm": [(-999, -110, "ضعيفة جدًا", "#B71C1C"), (-110, -100, "ضعيفة", "#F57C00"), (-100, -90, "متوسطة", "#FDD835"), (-90, -80, "جيدة", "#7CB342"), (-80, 999, "ممتازة", "#1B5E20")],
            "rsrq_db": [(-999, -20, "ضعيفة جدًا", "#B71C1C"), (-20, -15, "ضعيفة", "#F57C00"), (-15, -10, "متوسطة", "#FDD835"), (-10, -6, "جيدة", "#7CB342"), (-6, 999, "ممتازة", "#1B5E20")],
            "snr_db": [(-999, 0, "ضعيفة جدًا", "#B71C1C"), (0, 5, "ضعيفة", "#F57C00"), (5, 10, "متوسطة", "#FDD835"), (10, 20, "جيدة", "#7CB342"), (20, 999, "ممتازة", "#1B5E20")],
        }
        ranges = []
        for lower, upper, label, color in schemes[field]:
            symbol = QgsMarkerSymbol.createSimple({"name": "circle", "color": color, "outline_color": "#FFFFFF", "outline_width": "0.15", "size": "2.2"})
            ranges.append(QgsRendererRange(lower, upper, symbol, label))
        self.measurements_layer.setRenderer(QgsGraduatedSymbolRenderer(field, ranges))
        self.measurements_layer.triggerRepaint()

    def filter_measurements(self, operator_code):
        if not self._ensure_measurements_layer():
            return
        expression = "" if operator_code == "ALL" else f'"operator_code" = \'{operator_code}\''
        if not self.measurements_layer.setSubsetString(expression):
            self._message("تعذر تطبيق مرشح القياسات", expression, message_level("Warning"))
            return
        labels = {"ALL": "جميع الشركات", "ALMADAR": "المدار الجديد", "LIBYANA": "ليبيانا"}
        self.measurements_status_label.setText(
            f"العرض الحالي: {labels[operator_code]}\nعدد نقاط القياس: {self.measurements_layer.featureCount()}"
        )
        self.measurements_layer.triggerRepaint()

    def zoom_to_measurements(self):
        if not self._ensure_measurements_layer():
            return
        self.measurements_layer.updateExtents()
        self.iface.setActiveLayer(self.measurements_layer)
        self.iface.zoomToActiveLayer()

    def _ensure_measurements_layer(self):
        if self.measurements_layer is not None and self.measurements_layer.isValid():
            return True
        existing = QgsProject.instance().mapLayersByName(MEASUREMENTS_LAYER_NAME)
        if existing:
            self.measurements_layer = existing[0]
            return True
        self._message("طبقة القياسات غير محملة", "اضغط تحميل نقاط القياس أولًا.", message_level("Warning"))
        return False

    def _save_classes_table(self, metric):
        rows = []
        for row in range(self.classes_table.rowCount()):
            try:
                label = self.classes_table.item(row, 0).text().strip()
                lower = float(self.classes_table.item(row, 1).text())
                upper = float(self.classes_table.item(row, 2).text())
                color = self.classes_table.item(row, 3).text().strip()
            except Exception as exc:
                raise ValueError(f"تحقق من قيم التصنيف في الصف {row + 1}") from exc
            if lower >= upper:
                raise ValueError(f"الحد الأدنى يجب أن يكون أصغر من الأعلى في الصف {row + 1}")
            if not QColor(color).isValid():
                raise ValueError(f"رمز اللون غير صحيح في الصف {row + 1}")
            rows.append([label, lower, upper, color])
        rows.sort(key=lambda item: item[1])
        for previous, current in zip(rows, rows[1:]):
            if previous[2] != current[1]:
                raise ValueError("يجب أن تكون حدود الفئات متصلة دون فجوات أو تداخل")
        self.class_settings[metric] = rows

    def _load_classes_table(self, metric):
        for row, values in enumerate(self.class_settings[metric]):
            for column, value in enumerate(values):
                self.classes_table.setItem(row, column, QTableWidgetItem(str(value)))

    def _heatmap_metric_changed(self, *_args):
        try:
            self._save_classes_table(self.active_heatmap_metric)
        except ValueError:
            pass
        self.active_heatmap_metric = self.heatmap_metric_combo.currentData()
        self._load_classes_table(self.active_heatmap_metric)

    def reset_heatmap_classes(self):
        metric = self.heatmap_metric_combo.currentData()
        self.class_settings[metric] = [row[:] for row in DEFAULT_CLASSES[metric]]
        self._load_classes_table(metric)

    def create_idw_heatmap(self):
        if not self._ensure_measurements_layer():
            return
        metric = self.heatmap_metric_combo.currentData()
        operator_code = self.heatmap_operator_combo.currentData()
        try:
            self._save_classes_table(metric)
        except ValueError as exc:
            self._message("خطأ في التصنيفات", str(exc), message_level("Warning"))
            return
        self.measurements_layer.setSubsetString(f'"operator_code" = \'{operator_code}\' AND "{metric}" IS NOT NULL')
        if self.measurements_layer.featureCount() < 3:
            self._message("بيانات غير كافية", "يلزم وجود ثلاث نقاط صالحة على الأقل.", message_level("Warning"))
            return
        try:
            output_path = self._write_safe_idw(metric)
            operator_label = self.heatmap_operator_combo.currentText()
            raster = QgsRasterLayer(output_path, f"IDW {metric.upper()} - {operator_label}")
            if not raster.isValid():
                raise RuntimeError("تعذر فتح ناتج IDW كطبقة Raster")
            self._style_heatmap(raster, metric)
            QgsProject.instance().addMapLayer(raster)
            self.iface.setActiveLayer(raster)
            self.iface.zoomToActiveLayer()
            self._message("اكتملت الخريطة", f"تم إنشاء خريطة {metric.upper()} لشركة {operator_label}.", message_level("Success"))
        except Exception as exc:
            self._message("فشل إنشاء خريطة IDW", str(exc), message_level("Critical"))

    def _write_safe_idw(self, metric):
        import math
        import os
        import tempfile
        import numpy as np
        from osgeo import gdal, osr

        target_crs = QgsCoordinateReferenceSystem("EPSG:32633")
        transform = QgsCoordinateTransform(
            self.measurements_layer.crs(), target_crs, QgsProject.instance()
        )
        points = []
        for feature in self.measurements_layer.getFeatures():
            value = feature[metric]
            if value is None or feature.geometry().isNull():
                continue
            point = transform.transform(feature.geometry().asPoint())
            points.append((point.x(), point.y(), float(value)))
        if len(points) < 3:
            raise ValueError("لا توجد نقاط صالحة كافية لإنشاء خريطة IDW")

        data = np.asarray(points, dtype=np.float64)
        xs, ys, values = data[:, 0], data[:, 1], data[:, 2]
        pixel_size = float(self.pixel_size_spin.value())
        padding = pixel_size * 2
        xmin, xmax = xs.min() - padding, xs.max() + padding
        ymin, ymax = ys.min() - padding, ys.max() + padding
        width = max(1, int(math.ceil((xmax - xmin) / pixel_size)))
        height = max(1, int(math.ceil((ymax - ymin) / pixel_size)))
        if width * height > 25_000_000:
            raise ValueError("حجم الخلية صغير جدًا وينتج راسترًا ضخمًا؛ ارفع حجم الخلية")

        neighbours = min(int(self.neighbors_spin.value()), len(points))
        grid_x = xmin + (np.arange(width, dtype=np.float64) + 0.5) * pixel_size
        output = np.empty((height, width), dtype=np.float32)
        for row in range(height):
            grid_y = ymax - (row + 0.5) * pixel_size
            distance_squared = (grid_x[:, None] - xs[None, :]) ** 2 + (grid_y - ys[None, :]) ** 2
            nearest = np.argpartition(distance_squared, neighbours - 1, axis=1)[:, :neighbours]
            selected_distances = np.take_along_axis(distance_squared, nearest, axis=1)
            selected_values = values[nearest]
            exact = selected_distances <= 1e-12
            weights = 1.0 / np.maximum(selected_distances, 0.01)
            interpolated = np.sum(weights * selected_values, axis=1) / np.sum(weights, axis=1)
            exact_rows = exact.any(axis=1)
            if exact_rows.any():
                first_exact = exact.argmax(axis=1)
                interpolated[exact_rows] = selected_values[np.arange(width)[exact_rows], first_exact[exact_rows]]
            output[row, :] = interpolated.astype(np.float32)

        operator = self.heatmap_operator_combo.currentData().lower()
        handle, output_path = tempfile.mkstemp(prefix=f"telecom_idw_{operator}_{metric}_", suffix=".tif")
        os.close(handle)
        driver = gdal.GetDriverByName("GTiff")
        dataset = driver.Create(output_path, width, height, 1, gdal.GDT_Float32, options=["COMPRESS=LZW", "TILED=YES"])
        if dataset is None:
            raise RuntimeError("تعذر إنشاء ملف GeoTIFF")
        dataset.SetGeoTransform((xmin, pixel_size, 0.0, ymax, 0.0, -pixel_size))
        spatial_ref = osr.SpatialReference()
        spatial_ref.ImportFromEPSG(32633)
        dataset.SetProjection(spatial_ref.ExportToWkt())
        band = dataset.GetRasterBand(1)
        band.WriteArray(output)
        band.SetDescription(metric.upper())
        band.FlushCache()
        dataset.FlushCache()
        dataset = None
        return output_path

    def _style_heatmap(self, raster, metric):
        items = []
        for label, lower, upper, color in self.class_settings[metric]:
            items.append(QgsColorRampShader.ColorRampItem(upper, QColor(color), f"{label} ({lower} إلى {upper})"))
        shader_function = QgsColorRampShader()
        try:
            shader_function.setColorRampType(QgsColorRampShader.Type.Discrete)
        except AttributeError:
            shader_function.setColorRampType(QgsColorRampShader.Discrete)
        shader_function.setColorRampItemList(items)
        shader = QgsRasterShader()
        shader.setRasterShaderFunction(shader_function)
        raster.setRenderer(QgsSingleBandPseudoColorRenderer(raster.dataProvider(), 1, shader))
        raster.triggerRepaint()

    def refresh_study_areas(self):
        current_id = self.study_area_combo.currentData() if self.study_area_combo.count() else None
        self.study_area_combo.clear()
        self.study_area_combo.addItem("نطاق الأبراج المستطيل (تقديري)", "EXTENT")
        for layer in QgsProject.instance().mapLayers().values():
            if not isinstance(layer, QgsVectorLayer) or not layer.isValid():
                continue
            try:
                is_polygon = layer.geometryType() == Qgis.GeometryType.Polygon
            except AttributeError:
                is_polygon = layer.geometryType() == 2
            if is_polygon:
                self.study_area_combo.addItem(layer.name(), layer.id())
        index = self.study_area_combo.findData(current_id)
        self.study_area_combo.setCurrentIndex(index if index >= 0 else 0)

    def browse_osm_file(self):
        path, _selected_filter = QFileDialog.getOpenFileName(
            self, "اختيار ملف OpenStreetMap", "", "OSM PBF (*.osm.pbf *.pbf);;جميع الملفات (*)"
        )
        if path:
            self.osm_path_edit.setText(path)

    def extract_osm_data(self):
        import os

        osm_path = self.osm_path_edit.text().strip()
        if not osm_path or not os.path.isfile(osm_path):
            self._message("ملف OSM غير محدد", "اختر ملف libya-260903.osm.pbf من جهازك.", message_level("Warning"))
            return
        area_id = self.study_area_combo.currentData()
        if not area_id or area_id == "EXTENT":
            self._message(
                "حدود الدراسة غير محددة",
                "أنشئ حدود الدراسة من الأبراج ثم اختر طبقتها من قائمة منطقة الدراسة.",
                message_level("Warning"),
            )
            return
        area_layer = QgsProject.instance().mapLayer(area_id)
        if area_layer is None or not area_layer.isValid():
            self._message("حدود غير متاحة", "اضغط تحديث الحدود واختر طبقة صالحة.", message_level("Warning"))
            return
        connection_name = self.connection_combo.currentText().strip()
        if not connection_name:
            self._message("اتصال غير محدد", "اختر اتصال PostGIS أولًا.", message_level("Warning"))
            return

        try:
            boundary = self._study_boundary_utm(area_layer)
            outputs = self._extract_osm_layers(osm_path, boundary)
            counts = []
            for key, memory_layer in outputs.items():
                saved_layer = self._export_osm_layer_to_postgis(memory_layer, key, connection_name)
                QgsProject.instance().addMapLayer(saved_layer)
                counts.append(f"{OSM_OUTPUTS[key][0]}: {saved_layer.featureCount()}")
            self.osm_progress.setValue(4)
            self.osm_progress.setFormat("اكتمل الاستخراج")
            self.osm_status_label.setText("\n".join(counts))
            self._message("اكتمل استخراج OSM", "تم حفظ الطبقات الأربع داخل مخطط telecom.", message_level("Success"))
        except Exception as exc:
            self.osm_progress.setFormat("توقف الاستخراج")
            self._message("فشل استخراج بيانات OSM", str(exc), message_level("Critical"))

    def _study_boundary_utm(self, area_layer):
        target_crs = QgsCoordinateReferenceSystem("EPSG:32633")
        transform = QgsCoordinateTransform(area_layer.crs(), target_crs, QgsProject.instance())
        geometries = []
        for feature in area_layer.getFeatures():
            geometry = QgsGeometry(feature.geometry())
            if geometry.isNull() or geometry.isEmpty():
                continue
            geometry.transform(transform)
            geometries.append(geometry)
        if not geometries:
            raise ValueError("طبقة حدود الدراسة لا تحتوي على مضلع صالح")
        boundary = QgsGeometry.unaryUnion(geometries)
        if boundary.isNull() or boundary.isEmpty():
            raise ValueError("تعذر دمج مضلعات منطقة الدراسة")
        return boundary

    @staticmethod
    def _osm_tag(feature, key):
        import re

        names = feature.fields().names()
        if key in names:
            value = feature[key]
            if value is not None and str(value).strip() not in ("", "NULL"):
                return str(value).strip()
        if "other_tags" in names:
            tags = feature["other_tags"]
            if tags:
                match = re.search(r'"' + re.escape(key) + r'"=>"([^\"]*)"', str(tags))
                if match:
                    return match.group(1)
        return ""

    def _new_osm_output_layer(self, key):
        title, _table, geometry_type = OSM_OUTPUTS[key]
        layer = QgsVectorLayer(f"{geometry_type}?crs=EPSG:32633", title, "memory")
        provider = layer.dataProvider()
        provider.addAttributes([
            QgsField("id", QVariant.Int),
            QgsField("osm_id", QVariant.String, len=40),
            QgsField("name", QVariant.String, len=255),
            QgsField("category", QVariant.String, len=40),
            QgsField("subtype", QVariant.String, len=120),
        ])
        layer.updateFields()
        return layer

    def _extract_osm_layers(self, osm_path, boundary):
        specs = [
            ("roads", "lines", "highway"),
            ("buildings", "multipolygons", "building"),
            ("landuse", "multipolygons", "landuse"),
            ("places", "points", "place"),
            ("places", "multipolygons", "place"),
        ]
        outputs = {key: self._new_osm_output_layer(key) for key in OSM_OUTPUTS}
        counters = {key: 0 for key in OSM_OUTPUTS}
        completed = set()
        allowed_places = {"city", "town", "village", "suburb", "neighbourhood", "quarter", "hamlet"}
        for key, source_name, tag_name in specs:
            source = QgsVectorLayer(f"{osm_path}|layername={source_name}", source_name, "ogr")
            if not source.isValid():
                raise RuntimeError(f"تعذر قراءة طبقة {source_name} من ملف OSM")
            source_to_utm = QgsCoordinateTransform(source.crs(), QgsCoordinateReferenceSystem("EPSG:32633"), QgsProject.instance())
            utm_to_source = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:32633"), source.crs(), QgsProject.instance())
            request = QgsFeatureRequest().setFilterRect(utm_to_source.transformBoundingBox(boundary.boundingBox()))
            batch = []
            for source_feature in source.getFeatures(request):
                subtype = self._osm_tag(source_feature, tag_name)
                if not subtype or (key == "places" and subtype not in allowed_places):
                    continue
                geometry = QgsGeometry(source_feature.geometry())
                if geometry.isNull() or geometry.isEmpty():
                    continue
                geometry.transform(source_to_utm)
                if not geometry.intersects(boundary):
                    continue
                geometry = geometry.intersection(boundary)
                if geometry.isNull() or geometry.isEmpty():
                    continue
                if key == "places":
                    if source_name == "multipolygons":
                        geometry = geometry.pointOnSurface()
                elif key == "roads":
                    geometry.convertToMultiType()
                else:
                    geometry.convertToMultiType()
                counters[key] += 1
                output_feature = QgsFeature(outputs[key].fields())
                output_feature.setGeometry(geometry)
                osm_id = self._osm_tag(source_feature, "osm_id")
                output_feature.setAttributes([
                    counters[key], osm_id, self._osm_tag(source_feature, "name"), tag_name, subtype
                ])
                batch.append(output_feature)
                if len(batch) >= 1000:
                    outputs[key].dataProvider().addFeatures(batch)
                    batch = []
                    QApplication.processEvents()
            if batch:
                outputs[key].dataProvider().addFeatures(batch)
            outputs[key].updateExtents()
            completed.add(key)
            self.osm_progress.setValue(min(len(completed), 4))
            self.osm_progress.setFormat(f"جارٍ الاستخراج: {OSM_OUTPUTS[key][0]}")
            QApplication.processEvents()
        return outputs

    def _export_osm_layer_to_postgis(self, layer, key, connection_name):
        _title, table_name, geometry_type = OSM_OUTPUTS[key]
        metadata = QgsProviderRegistry.instance().providerMetadata("postgres")
        connection = metadata.findConnection(connection_name)
        destination = QgsDataSourceUri(connection.uri())
        destination.setDataSource(SCHEMA_NAME, table_name, GEOMETRY_COLUMN, "", "id")
        export_result = QgsVectorLayerExporter.exportLayer(
            layer,
            destination.uri(False),
            "postgres",
            QgsCoordinateReferenceSystem("EPSG:32633"),
            False,
            {"overwrite": True, "forceSinglePartGeometry": False},
        )
        error_code = export_result[0] if isinstance(export_result, tuple) else export_result
        error_message = export_result[1] if isinstance(export_result, tuple) and len(export_result) > 1 else ""
        numeric_error = error_code.value if hasattr(error_code, "value") else int(error_code)
        if numeric_error != 0:
            raise RuntimeError(f"تعذر حفظ telecom.{table_name}: {error_message}")
        base_uri = connection.uri()
        separator = "" if base_uri.endswith(" ") else " "
        layer_uri = (
            f"{base_uri}{separator}key='id' srid=32633 type={geometry_type} "
            f'table="{SCHEMA_NAME}"."{table_name}" ({GEOMETRY_COLUMN}) sql='
        )
        saved_layer = QgsVectorLayer(layer_uri, OSM_OUTPUTS[key][0], "postgres")
        if not saved_layer.isValid():
            raise RuntimeError(f"تم التصدير ولكن تعذر فتح telecom.{table_name}")
        for old_layer in QgsProject.instance().mapLayersByName(OSM_OUTPUTS[key][0]):
            QgsProject.instance().removeMapLayer(old_layer.id())
        return saved_layer

    def _model_boundary(self):
        area_id = self.study_area_combo.currentData()
        if not area_id or area_id == "EXTENT":
            raise ValueError("أنشئ أو اختر طبقة حدود منطقة الدراسة أولًا")
        area_layer = QgsProject.instance().mapLayer(area_id)
        if area_layer is None or not area_layer.isValid():
            raise ValueError("طبقة حدود منطقة الدراسة غير متاحة")
        boundary = self._study_boundary_utm(area_layer)
        rect = boundary.boundingBox()
        return boundary, (rect.xMinimum(), rect.yMinimum(), rect.xMaximum(), rect.yMaximum())

    def _tower_model_points(self, operator_code):
        if not self._ensure_layer():
            raise ValueError("حمّل طبقة الأبراج أولًا")
        transform = QgsCoordinateTransform(self.layer.crs(), QgsCoordinateReferenceSystem("EPSG:32633"), QgsProject.instance())
        previous_subset = self.layer.subsetString()
        points = []
        try:
            self.layer.setSubsetString("")
            for feature in self.layer.getFeatures():
                if operator_code != "ALL" and str(feature["operator_code"]) != operator_code:
                    continue
                geometry = feature.geometry()
                if not geometry.isNull() and not geometry.isEmpty():
                    point = transform.transform(geometry.asPoint())
                    points.append((point.x(), point.y()))
        finally:
            self.layer.setSubsetString(previous_subset)
        return points

    def create_tower_kde(self):
        try:
            boundary, extent = self._model_boundary()
            operator = self.kde_operator_combo.currentData()
            points = self._tower_model_points(operator)
            if not points:
                raise ValueError("لا توجد أبراج صالحة للخيار المحدد")
            path = create_kde(
                boundary.asWkt(), extent, points, float(self.model_cell_spin.value()),
                float(self.kde_bandwidth_spin.value()),
            )
            label = self.kde_operator_combo.currentText()
            raster = QgsRasterLayer(path, f"KDE كثافة الأبراج - {label}")
            if not raster.isValid():
                raise RuntimeError("تعذر فتح راستر KDE")
            statistics = raster.dataProvider().bandStatistics(1)
            maximum = statistics.maximumValue
            if maximum <= 0:
                raise ValueError("ناتج الكثافة فارغ")
            self._style_model_raster(raster, [maximum * i / 5.0 for i in range(1, 6)],
                                     ["منخفضة جدًا", "منخفضة", "متوسطة", "مرتفعة", "مرتفعة جدًا"])
            QgsProject.instance().addMapLayer(raster)
            self.iface.setActiveLayer(raster); self.iface.zoomToActiveLayer()
            self.models_status_label.setText(
                f"تم إنشاء KDE لـ {len(points)} برجًا؛ الوحدة برج/كم²، نطاق البحث {self.kde_bandwidth_spin.value():.0f} م."
            )
            self._message("اكتمل KDE", "تم إنشاء سطح كثافة الأبراج وقصه بحدود الدراسة.", message_level("Success"))
        except Exception as exc:
            self._message("فشل إنشاء KDE", str(exc), message_level("Critical"))

    def create_suitability_model(self):
        try:
            boundary, extent = self._model_boundary()
            weights = [float(spin.value()) for spin in self.suitability_weight_spins]
            if abs(sum(weights) - 100.0) > 0.01:
                raise ValueError(f"مجموع أوزان المعايير يجب أن يساوي 100%، والمجموع الحالي {sum(weights):.0f}%")
            operator = self.suitability_operator_combo.currentData()
            towers = self._tower_model_points(operator)
            buildings_layer = self._required_model_layer("buildings")
            roads_layer = self._required_model_layer("roads")
            landuse_layer = self._required_model_layer("landuse")
            buildings = self._layer_centres_utm(buildings_layer)
            roads = self._layer_wkts_utm(roads_layer)
            land_score_map = self._read_landuse_scores()
            landuses = []
            transform = QgsCoordinateTransform(landuse_layer.crs(), QgsCoordinateReferenceSystem("EPSG:32633"), QgsProject.instance())
            for feature in landuse_layer.getFeatures():
                geometry = QgsGeometry(feature.geometry())
                if geometry.isNull() or geometry.isEmpty():
                    continue
                geometry.transform(transform)
                category = self._landuse_ar(str(feature["subtype"] or ""))
                score = land_score_map.get(category, land_score_map["غير مصنف/أخرى"]) / 100.0
                landuses.append((geometry.asWkt(), score))
            measurements = self._rsrp_model_points(operator)
            path, candidates = create_suitability(
                boundary.asWkt(), extent, towers, buildings, roads, landuses, measurements,
                float(self.model_cell_spin.value()), weights,
            )
            label = self.suitability_operator_combo.currentText()
            raster = QgsRasterLayer(path, f"الملاءمة المكانية - {label}")
            if not raster.isValid():
                raise RuntimeError("تعذر فتح راستر الملاءمة")
            self._style_model_raster(raster, [20, 40, 60, 80, 100],
                                     ["منخفضة جدًا", "منخفضة", "متوسطة", "مرتفعة", "مرتفعة جدًا"])
            QgsProject.instance().addMapLayer(raster)
            self._add_candidate_layer(candidates, label)
            self.models_status_label.setText(
                f"تم إنشاء نموذج الملاءمة لشركة {label} واستخراج {len(candidates)} مواقع مرشحة، "
                f"مع استخدام {len(measurements)} قياس RSRP ضمن نطاق دعم 1500 م."
            )
            self._message("اكتمل نموذج الملاءمة", "تم إنشاء الراستر وأفضل المواقع المرشحة.", message_level("Success"))
        except Exception as exc:
            self._message("فشل نموذج الملاءمة", str(exc), message_level("Critical"))

    def _required_model_layer(self, key):
        layers = QgsProject.instance().mapLayersByName(OSM_OUTPUTS[key][0])
        if not layers or not layers[0].isValid():
            raise ValueError(f"طبقة {OSM_OUTPUTS[key][0]} غير محملة؛ نفّذ استخراج OSM أولًا")
        return layers[0]

    @staticmethod
    def _layer_centres_utm(layer):
        transform = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem("EPSG:32633"), QgsProject.instance())
        points = []
        for feature in layer.getFeatures():
            geometry = QgsGeometry(feature.geometry())
            if geometry.isNull() or geometry.isEmpty():
                continue
            geometry.transform(transform)
            point = geometry.centroid().asPoint()
            points.append((point.x(), point.y()))
        return points

    @staticmethod
    def _layer_wkts_utm(layer):
        transform = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem("EPSG:32633"), QgsProject.instance())
        wkts = []
        for feature in layer.getFeatures():
            geometry = QgsGeometry(feature.geometry())
            if geometry.isNull() or geometry.isEmpty():
                continue
            geometry.transform(transform); wkts.append(geometry.asWkt())
        return wkts

    def _rsrp_model_points(self, operator_code):
        if not self._ensure_measurements_layer():
            raise ValueError("حمّل نقاط القياس أولًا")
        transform = QgsCoordinateTransform(self.measurements_layer.crs(), QgsCoordinateReferenceSystem("EPSG:32633"), QgsProject.instance())
        previous_subset = self.measurements_layer.subsetString()
        points = []
        try:
            self.measurements_layer.setSubsetString("")
            for feature in self.measurements_layer.getFeatures():
                if str(feature["operator_code"]) != operator_code or feature["rsrp_dbm"] is None:
                    continue
                geometry = feature.geometry()
                if geometry.isNull() or geometry.isEmpty():
                    continue
                point = transform.transform(geometry.asPoint())
                points.append((point.x(), point.y(), float(feature["rsrp_dbm"])))
        finally:
            self.measurements_layer.setSubsetString(previous_subset)
        if len(points) < 3:
            raise ValueError("لا توجد قياسات RSRP كافية للشركة المختارة")
        return points

    def _read_landuse_scores(self):
        scores = {}
        for row in range(self.landuse_scores_table.rowCount()):
            name = self.landuse_scores_table.item(row, 0).text()
            try:
                value = float(self.landuse_scores_table.item(row, 1).text())
            except Exception as exc:
                raise ValueError(f"درجة استعمال الأرض غير صحيحة في الصف {row + 1}") from exc
            if not 0 <= value <= 100:
                raise ValueError("درجات استعمالات الأراضي يجب أن تكون بين 0 و100")
            scores[name] = value
        return scores

    def _style_model_raster(self, raster, limits, labels):
        colors = ["#D73027", "#FC8D59", "#FEE08B", "#91CF60", "#1A9850"]
        items = [QgsColorRampShader.ColorRampItem(limit, QColor(color), label)
                 for limit, label, color in zip(limits, labels, colors)]
        function = QgsColorRampShader()
        try: function.setColorRampType(QgsColorRampShader.Type.Discrete)
        except AttributeError: function.setColorRampType(QgsColorRampShader.Discrete)
        function.setColorRampItemList(items)
        shader = QgsRasterShader(); shader.setRasterShaderFunction(function)
        raster.setRenderer(QgsSingleBandPseudoColorRenderer(raster.dataProvider(), 1, shader))
        raster.triggerRepaint()

    def _add_candidate_layer(self, candidates, operator_label):
        name = f"أفضل مواقع الأبراج المقترحة - {operator_label}"
        for old in QgsProject.instance().mapLayersByName(name):
            QgsProject.instance().removeMapLayer(old.id())
        layer = QgsVectorLayer("Point?crs=EPSG:32633", name, "memory")
        layer.dataProvider().addAttributes([
            QgsField("rank", QVariant.Int), QgsField("score", QVariant.Double),
            QgsField("longitude", QVariant.Double), QgsField("latitude", QVariant.Double),
        ])
        layer.updateFields()
        to_wgs84 = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:32633"), QgsCoordinateReferenceSystem("EPSG:4326"), QgsProject.instance())
        features = []
        self.candidates_table.setRowCount(len(candidates))
        for row, (rank, score, x, y) in enumerate(candidates):
            geographic = to_wgs84.transform(QgsPointXY(x, y))
            feature = QgsFeature(layer.fields()); feature.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
            feature.setAttributes([rank, score, geographic.x(), geographic.y()]); features.append(feature)
            values = [rank, f"{score:.2f}", f"{geographic.x():.6f}", f"{geographic.y():.6f}"]
            for column, value in enumerate(values):
                item = QTableWidgetItem(str(value)); item.setTextAlignment(ALIGN_CENTER)
                self.candidates_table.setItem(row, column, item)
        layer.dataProvider().addFeatures(features); layer.updateExtents()
        symbol = QgsMarkerSymbol.createSimple({"name":"star", "color":"#7C3AED", "outline_color":"#FFFFFF", "size":"5"})
        layer.renderer().setSymbol(symbol)
        QgsProject.instance().addMapLayer(layer)

    def run_spatial_relations(self):
        if not self._ensure_layer():
            return
        required = {
            "buildings": OSM_OUTPUTS["buildings"][0],
            "roads": OSM_OUTPUTS["roads"][0],
            "landuse": OSM_OUTPUTS["landuse"][0],
        }
        layers = {}
        missing = []
        for key, name in required.items():
            found = QgsProject.instance().mapLayersByName(name)
            if found and found[0].isValid():
                layers[key] = found[0]
            else:
                missing.append(name)
        if missing:
            self._message(
                "طبقات ناقصة",
                "نفّذ استخراج OSM أولًا. الطبقات غير الموجودة: " + "، ".join(missing),
                message_level("Warning"),
            )
            return

        previous_subset = self.layer.subsetString()
        try:
            self.layer.setSubsetString("")
            radius = float(self.relation_radius_spin.value())
            target_crs = QgsCoordinateReferenceSystem("EPSG:32633")
            tower_transform = QgsCoordinateTransform(self.layer.crs(), target_crs, QgsProject.instance())
            towers = []
            for feature in self.layer.getFeatures():
                geometry = feature.geometry()
                if geometry.isNull() or geometry.isEmpty():
                    continue
                point = tower_transform.transform(geometry.asPoint())
                towers.append({
                    "id": str(feature["tower_id"]),
                    "operator": str(feature["operator_code"]),
                    "point": point,
                    "geometry": QgsGeometry.fromPointXY(point),
                })
            if not towers:
                raise ValueError("لا توجد أبراج صالحة للتحليل")

            building_index, building_cache = self._metric_spatial_cache(layers["buildings"])
            road_index, road_cache = self._metric_spatial_cache(layers["roads"])
            landuse_index, landuse_cache = self._metric_spatial_cache(layers["landuse"])
            buffer_area_km2 = (3.141592653589793 * radius * radius) / 1_000_000.0
            building_rows = []
            road_rows = []
            landuse_counts = {}

            for position, tower in enumerate(towers, 1):
                buffer_geom = tower["geometry"].buffer(radius, 24)
                building_ids = building_index.intersects(buffer_geom.boundingBox())
                building_count = 0
                building_area = 0.0
                for feature_id in building_ids:
                    geometry, _subtype = building_cache[feature_id]
                    if not geometry.intersects(buffer_geom):
                        continue
                    clipped = geometry.intersection(buffer_geom)
                    if not clipped.isEmpty():
                        building_count += 1
                        building_area += clipped.area()
                building_density = building_count / buffer_area_km2
                coverage = min(100.0, building_area / (buffer_area_km2 * 1_000_000.0) * 100.0)
                building_rows.append([
                    tower["id"], self._operator_ar(tower["operator"]), building_count,
                    building_area, building_density, coverage, "", radius,
                ])

                nearest_road_distance = None
                nearest_road_type = "لا يوجد"
                nearest_ids = road_index.nearestNeighbor(tower["point"], 1)
                if nearest_ids:
                    nearest_geometry, nearest_road_type = road_cache[nearest_ids[0]]
                    nearest_road_distance = nearest_geometry.distance(tower["geometry"])
                road_length_m = 0.0
                for feature_id in road_index.intersects(buffer_geom.boundingBox()):
                    geometry, _subtype = road_cache[feature_id]
                    if geometry.intersects(buffer_geom):
                        clipped = geometry.intersection(buffer_geom)
                        if not clipped.isEmpty():
                            road_length_m += clipped.length()
                road_length_km = road_length_m / 1000.0
                road_rows.append([
                    tower["id"], self._operator_ar(tower["operator"]),
                    nearest_road_distance if nearest_road_distance is not None else -1,
                    nearest_road_type or "غير مصنف", road_length_km,
                    road_length_km / buffer_area_km2, radius,
                ])

                candidates = []
                for feature_id in landuse_index.intersects(tower["geometry"].boundingBox()):
                    geometry, subtype = landuse_cache[feature_id]
                    if geometry.intersects(tower["geometry"]):
                        candidates.append((geometry.area(), subtype))
                raw_landuse = min(candidates, key=lambda item: item[0])[1] if candidates else ""
                category = self._landuse_ar(raw_landuse)
                landuse_counts[category] = landuse_counts.get(category, 0) + 1
                if position % 15 == 0:
                    self.relations_status_label.setText(f"جارٍ تحليل البرج {position} من {len(towers)}...")
                    QApplication.processEvents()

            densities = sorted(row[4] for row in building_rows)
            low_limit = densities[max(0, int(len(densities) / 3) - 1)]
            high_limit = densities[max(0, int(2 * len(densities) / 3) - 1)]
            for row in building_rows:
                row[6] = "منخفضة" if row[4] <= low_limit else ("متوسطة" if row[4] <= high_limit else "مرتفعة")

            landuse_rows = []
            total = len(towers)
            for category, count in sorted(landuse_counts.items(), key=lambda item: (-item[1], item[0])):
                landuse_rows.append([category, count, count * 100.0 / total])
            landuse_rows.append(["الإجمالي", total, 100.0])
            self._fill_relation_tables(building_rows, road_rows, landuse_rows)
            self.relations_status_label.setText(
                f"تم تحليل {total} برجًا ضمن نصف قطر {radius:.0f} م. "
                "تصنيف كثافة المباني نسبي وفق أثلاث القيم داخل منطقة الدراسة."
            )
            self._message("اكتمل التحليل المكاني", "تم حساب علاقات الأبراج بالمباني والطرق واستعمالات الأراضي.", message_level("Success"))
        except Exception as exc:
            self._message("فشل التحليل المكاني", str(exc), message_level("Critical"))
        finally:
            self.layer.setSubsetString(previous_subset)
            self.layer.triggerRepaint()

    def _metric_spatial_cache(self, layer):
        target_crs = QgsCoordinateReferenceSystem("EPSG:32633")
        transform = QgsCoordinateTransform(layer.crs(), target_crs, QgsProject.instance())
        index = QgsSpatialIndex()
        cache = {}
        subtype_exists = "subtype" in layer.fields().names()
        for source_feature in layer.getFeatures():
            geometry = QgsGeometry(source_feature.geometry())
            if geometry.isNull() or geometry.isEmpty():
                continue
            geometry.transform(transform)
            indexed_feature = QgsFeature()
            indexed_feature.setId(source_feature.id())
            indexed_feature.setGeometry(geometry)
            index.addFeature(indexed_feature)
            subtype = str(source_feature["subtype"] or "") if subtype_exists else ""
            cache[source_feature.id()] = (geometry, subtype)
        return index, cache

    @staticmethod
    def _operator_ar(code):
        return {"ALMADAR": "المدار الجديد", "LIBYANA": "ليبيانا"}.get(code, code)

    @staticmethod
    def _landuse_ar(value):
        mapping = {
            "residential": "المناطق السكنية",
            "commercial": "المناطق التجارية", "retail": "المناطق التجارية",
            "industrial": "المناطق الصناعية",
            "government": "المناطق الإدارية والخدمية", "civic": "المناطق الإدارية والخدمية",
            "institutional": "المناطق الإدارية والخدمية", "education": "المناطق الإدارية والخدمية",
            "military": "المناطق الإدارية والخدمية",
            "grass": "المناطق المفتوحة والخضراء", "meadow": "المناطق المفتوحة والخضراء",
            "forest": "المناطق المفتوحة والخضراء", "recreation_ground": "المناطق المفتوحة والخضراء",
            "farmland": "المناطق المفتوحة والخضراء", "orchard": "المناطق المفتوحة والخضراء",
            "cemetery": "المناطق المفتوحة والخضراء",
            "construction": "مناطق قيد الإنشاء",
            "railway": "النقل والمرافق", "port": "النقل والمرافق",
        }
        if not value:
            return "غير مصنف"
        return mapping.get(value, "استعمالات أخرى")

    def _fill_relation_tables(self, building_rows, road_rows, landuse_rows):
        def fill(table, rows, decimals):
            table.setSortingEnabled(False)
            table.setRowCount(len(rows))
            for row_index, values in enumerate(rows):
                for column_index, value in enumerate(values):
                    if isinstance(value, float):
                        text = f"{value:.{decimals}f}"
                    else:
                        text = str(value)
                    item = QTableWidgetItem(text)
                    item.setTextAlignment(ALIGN_CENTER)
                    table.setItem(row_index, column_index, item)
            table.setSortingEnabled(True)
        fill(self.building_relation_table, building_rows, 2)
        fill(self.road_relation_table, road_rows, 3)
        fill(self.landuse_relation_table, landuse_rows, 1)

    def create_tower_study_area(self):
        if not self._ensure_layer():
            return
        previous_subset = self.layer.subsetString()
        try:
            if not self.layer.setSubsetString(""):
                raise ValueError("تعذر قراءة جميع أبراج الشركتين")
            target_crs = QgsCoordinateReferenceSystem("EPSG:32633")
            transform = QgsCoordinateTransform(self.layer.crs(), target_crs, QgsProject.instance())
            points = []
            for feature in self.layer.getFeatures():
                geometry = feature.geometry()
                if geometry.isNull() or geometry.isEmpty():
                    continue
                points.append(transform.transform(geometry.asPoint()))
            if len(points) < 3:
                raise ValueError("يلزم وجود ثلاثة أبراج صالحة على الأقل لإنشاء الحدود")

            hull = QgsGeometry.fromMultiPointXY(points).convexHull()
            distance = float(self.study_buffer_spin.value())
            boundary = hull.buffer(distance, 24)
            if boundary.isNull() or boundary.isEmpty() or boundary.area() <= 0:
                raise ValueError("تعذر إنشاء مضلع صالح لمنطقة الدراسة")

            for old_layer in QgsProject.instance().mapLayersByName(STUDY_AREA_LAYER_NAME):
                QgsProject.instance().removeMapLayer(old_layer.id())
            study_layer = QgsVectorLayer("Polygon?crs=EPSG:32633", STUDY_AREA_LAYER_NAME, "memory")
            if not study_layer.isValid():
                raise RuntimeError("تعذر إنشاء طبقة حدود منطقة الدراسة")
            feature = QgsFeature()
            feature.setGeometry(boundary)
            study_layer.dataProvider().addFeature(feature)
            study_layer.updateExtents()
            symbol = QgsFillSymbol.createSimple({
                "color": "43,108,176,35",
                "outline_color": "#2B6CB0",
                "outline_width": "0.8",
            })
            study_layer.renderer().setSymbol(symbol)
            QgsProject.instance().addMapLayer(study_layer)
            self.refresh_study_areas()
            index = self.study_area_combo.findData(study_layer.id())
            if index >= 0:
                self.study_area_combo.setCurrentIndex(index)
            self.iface.setActiveLayer(study_layer)
            self.iface.zoomToActiveLayer()
            area_km2 = boundary.area() / 1_000_000.0
            self._message(
                "تم إنشاء حدود الدراسة",
                f"غلاف محدب لـ {len(points)} برجًا مع حزام {distance:.0f} م؛ المساحة {area_km2:.2f} كم².",
                message_level("Success"),
            )
        except Exception as exc:
            self._message("تعذر إنشاء حدود الدراسة", str(exc), message_level("Critical"))
        finally:
            self.layer.setSubsetString(previous_subset)
            self.layer.triggerRepaint()

    def run_nearest_neighbor(self):
        if not self._ensure_layer():
            return
        previous_subset = self.layer.subsetString()
        operator_code = self.nearest_operator_combo.currentData()
        analysis_subset = "" if operator_code == "ALL" else f'"operator_code" = \'{operator_code}\''
        try:
            if not self.layer.setSubsetString(analysis_subset):
                raise ValueError("تعذر تطبيق نطاق الشركة المختارة على طبقة الأبراج")
            result = self._calculate_nearest_neighbor()
        except Exception as exc:
            self._message("تعذر تنفيذ تحليل الجار الأقرب", str(exc), message_level("Critical"))
            return
        finally:
            self.layer.setSubsetString(previous_subset)
            self.layer.triggerRepaint()
        rows = [
            ("Nearest Neighbor Ratio", f"{result['ratio']:.3f}", result["pattern"]),
            ("Z-Score", f"{result['z_score']:.3f}", result["significance"]),
            ("P-Value", f"{result['p_value']:.6f}", result["p_interpretation"]),
            ("Expected Mean Distance (m)", f"{result['expected']:.2f}", "المسافة المتوقعة"),
            ("Observed Mean Distance (m)", f"{result['observed']:.2f}", "المسافة الفعلية"),
            ("Study Area (km²)", f"{result['area_m2'] / 1_000_000:.3f}", "مساحة التحليل"),
            ("Tower Count", str(result["count"]), "عدد الأبراج الداخلة في التحليل"),
        ]
        self.nearest_results_table.setRowCount(len(rows))
        for row, values in enumerate(rows):
            for column, value in enumerate(values):
                item = QTableWidgetItem(value)
                item.setTextAlignment(ALIGN_CENTER)
                self.nearest_results_table.setItem(row, column, item)
        self.nearest_note_label.setText(result["area_note"])
        self._message("اكتمل التحليل", "تم حساب مؤشرات الجار الأقرب للأبراج.", message_level("Success"))

    def _calculate_nearest_neighbor(self):
        import math
        target_crs = QgsCoordinateReferenceSystem("EPSG:32633")
        tower_transform = QgsCoordinateTransform(self.layer.crs(), target_crs, QgsProject.instance())
        operator_code = self.nearest_operator_combo.currentData()
        points = []
        for feature in self.layer.getFeatures():
            if operator_code != "ALL" and feature["operator_code"] != operator_code:
                continue
            geometry = feature.geometry()
            if geometry.isNull() or geometry.isEmpty():
                continue
            points.append(tower_transform.transform(geometry.asPoint()))

        area_source = self.study_area_combo.currentData()
        if area_source != "EXTENT":
            area_layer = QgsProject.instance().mapLayer(area_source)
            if area_layer is None or not area_layer.isValid():
                raise ValueError("طبقة منطقة الدراسة غير متاحة؛ اضغط تحديث الحدود")
            area_transform = QgsCoordinateTransform(area_layer.crs(), target_crs, QgsProject.instance())
            geometries = []
            for feature in area_layer.getFeatures():
                geometry = QgsGeometry(feature.geometry())
                if geometry.isNull() or geometry.isEmpty():
                    continue
                geometry.transform(area_transform)
                geometries.append(geometry)
            if not geometries:
                raise ValueError("طبقة منطقة الدراسة لا تحتوي مضلعات صالحة")
            boundary = QgsGeometry.unaryUnion(geometries)
            points = [point for point in points if boundary.intersects(QgsGeometry.fromPointXY(point))]
            area_m2 = boundary.area()
            area_note = "تم الحساب باستخدام الحدود الفعلية لطبقة منطقة الدراسة المختارة."
        else:
            if len(points) < 2:
                raise ValueError("يلزم برجان صالحان على الأقل")
            xs = [point.x() for point in points]
            ys = [point.y() for point in points]
            area_m2 = (max(xs) - min(xs)) * (max(ys) - min(ys))
            area_note = "تنبيه: استُخدم المستطيل المحيط بالأبراج كتقدير للمساحة؛ اختر حدود منطقة الدراسة للحصول على نتيجة قابلة للاعتماد البحثي."

        count = len(points)
        if count < 2:
            raise ValueError("يلزم وجود برجين على الأقل داخل منطقة الدراسة")
        if area_m2 <= 0:
            raise ValueError("مساحة منطقة الدراسة تساوي صفرًا أو غير صالحة")
        nearest_distances = []
        for index, point in enumerate(points):
            nearest_distances.append(min(
                math.hypot(point.x() - other.x(), point.y() - other.y())
                for other_index, other in enumerate(points) if other_index != index
            ))
        observed = sum(nearest_distances) / count
        expected = 0.5 * math.sqrt(area_m2 / count)
        ratio = observed / expected
        standard_error = 0.26136 * math.sqrt(area_m2) / count
        z_score = (observed - expected) / standard_error
        p_value = math.erfc(abs(z_score) / math.sqrt(2.0))
        pattern = "توزيع متجمع" if ratio < 1 else ("توزيع متباعد" if ratio > 1 else "توزيع عشوائي")
        abs_z = abs(z_score)
        if abs_z >= 2.58:
            significance = "دلالة إحصائية قوية جدًا (99%)"
        elif abs_z >= 1.96:
            significance = "دلالة إحصائية (95%)"
        elif abs_z >= 1.65:
            significance = "دلالة إحصائية محدودة (90%)"
        else:
            significance = "لا توجد دلالة إحصائية كافية"
        return {
            "ratio": ratio, "z_score": z_score, "p_value": p_value,
            "expected": expected, "observed": observed, "area_m2": area_m2,
            "count": count, "pattern": pattern, "significance": significance,
            "p_interpretation": "ذو دلالة إحصائية" if p_value < 0.05 else "غير دال إحصائيًا",
            "area_note": area_note,
        }

    def apply_filter(self, operator_code):
        if not self._ensure_layer():
            return
        if operator_code == "ALL":
            expression = ""
        else:
            expression = f'"operator_code" = \'{operator_code}\''
        if not self.layer.setSubsetString(expression):
            self._message("تعذر تطبيق المرشح", expression, message_level("Warning"))
            return
        self.layer.triggerRepaint()
        self._update_counts(operator_code)

    def _update_counts(self, active_filter="ALL"):
        if self.layer is None or not self.layer.isValid():
            self.status_label.setText("لم يتم تحميل الطبقة بعد")
            return
        visible_count = self.layer.featureCount()
        label = {
            "ALL": "جميع الشركات",
            "ALMADAR": "المدار الجديد",
            "LIBYANA": "ليبيانا",
        }.get(active_filter, active_filter)
        self.status_label.setText(f"العرض الحالي: {label}\nعدد الأبراج: {visible_count}")

    def zoom_to_visible(self):
        if not self._ensure_layer():
            return
        if self.layer.featureCount() <= 0:
            self._message("لا توجد أبراج", "لا توجد مواقع ضمن المرشح الحالي.", message_level("Warning"))
            return
        self.layer.updateExtents()
        self.iface.setActiveLayer(self.layer)
        self.iface.zoomToActiveLayer()

    def _ensure_layer(self):
        if self.layer is not None and self.layer.isValid():
            return True
        existing = QgsProject.instance().mapLayersByName(LAYER_NAME)
        if existing:
            self.layer = existing[0]
            return True
        self._message("الطبقة غير محملة", "اضغط تحميل الأبراج أولًا.", message_level("Warning"))
        return False

    def _message(self, title, text, level):
        self.iface.messageBar().pushMessage(title, text, level=level, duration=5)
